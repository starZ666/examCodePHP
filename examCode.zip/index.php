<!DOCTYPE HTML>
<html>
<body>
<table>
    <tr>
        <td>Color</td>
        <td>Votes</td>
    </tr>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "color_test";

        $conn = mysqli_connect($servername, $username, $passwords,$dbname);
        $sql = "SELECT * FROM colors";
        $result = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td><a href=''><span onclick='showcolor(\"$row[Color]\")'>$row[Color]</span></a></td>";
            echo "</tr>";
        }
        ?>
</table>
<script>
    function showcolor(str) {

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var node = document.createElement("TD");
                    btn.innerHTML = this.responseText;
                    document.body.child.lastchild.appendchild(node);
                }
            };
            xmlhttp.open("GET", "gethint.php?q=" + str, true);
            xmlhttp.send();

    }
</script>

</body>
</html>